using UnityEngine;
using System;

public class CameraControl : MonoBehaviour
{

    // Public config fields
    public TransformPair[] views;
    public float scrollValue = 0.15F;
    public double snapSeconds = 2.0F;

    // Private fields
    private Transform nextView;
    private int currentViewIndex = 0;

    private float scrollAccumulator = 0;
    private double lastScroll = 0;
    private bool insideDetail = false;
    private GameObject middlePositionGO;


    private Vector3 fp;   //First touch position
    private Vector3 lp;   //Last touch position
    private float dragDistance;  //minimum distance for a swipe to be registered


    // Start is called before the first frame update
    void Start()
    {
        Input.simulateMouseWithTouches = true;

        nextView = views[currentViewIndex].standardView;
        middlePositionGO = new GameObject();
    }

    void Update()
    {
        var currentTime = Time.realtimeSinceStartupAsDouble;
        RaycastHit hit;

        // ------- Touch experiments -------
        if (Input.touchCount == 1) // user is touching the screen with a single touch
        {
            Touch touch = Input.GetTouch(0); // get the touch
            if (touch.phase == TouchPhase.Began) //check for the first touch
            {
                fp = touch.position;
                lp = touch.position;
            }
            else if (touch.phase == TouchPhase.Moved) // update the last position based on where they moved
            {
                lp = touch.position;
            }
            else if (touch.phase == TouchPhase.Ended) //check if the finger is removed from the screen
            {
                lp = touch.position;  //last touch position. Ommitted if you use list
 
                //Check if drag distance is greater than 20% of the screen height
                if (!insideDetail && (Mathf.Abs(lp.x - fp.x) > dragDistance || Mathf.Abs(lp.y - fp.y) > dragDistance))
                {//It's a drag
                 //check if the drag is vertical or horizontal
                    if (Mathf.Abs(lp.x - fp.x) > Mathf.Abs(lp.y - fp.y))
                    {   //If the horizontal movement is greater than the vertical movement...
                        if ((lp.x > fp.x))  //If the movement was to the right)
                        {   //Right swipe
                            Debug.Log("Right Swipe");
                            currentViewIndex --;

                            if (currentViewIndex < 0)
                                currentViewIndex = 0;

                            nextView = views[currentViewIndex].standardView;
                        }
                        else
                        {   //Left swipe
                            Debug.Log("Left Swipe");
                            currentViewIndex ++;

                            if (currentViewIndex >= views.Length)
                                currentViewIndex = views.Length - 1;

                            nextView = views[currentViewIndex].standardView;
                        }
                    }
                    else
                    {   //the vertical movement is greater than the horizontal movement
                        if (lp.y > fp.y)  //If the movement was up
                        {   //Up swipe
                            Debug.Log("Up Swipe");
                        }
                        else
                        {   //Down swipe
                            Debug.Log("Down Swipe");
                        }
                    }
                }
                else
                {   //It's a tap as the drag distance is less than 20% of the screen height
                    Debug.Log("Tap");
                    if (Physics.Raycast(Camera.main.ScreenPointToRay(lp), out hit))
                    {
                        if (hit.collider.tag == "Artwork") 
                        {
                            WebGlInterface.ArtworkOpen(currentViewIndex.ToString());
                            insideDetail = true;
                            nextView = views[currentViewIndex].closeView;
                        }
                        else if (hit.collider.tag == "Restart")
                        {
                            BackToStart();
                        }
                    }
                }
            }
        }


        // #########################
        // #  NON-MOBILE CONTROLS  #
        // #########################

        // ------- Object click detection -------

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
        {
            if (Input.GetMouseButtonDown(0) && hit.collider.tag == "Artwork") 
            {
                WebGlInterface.ArtworkOpen(currentViewIndex.ToString());
                insideDetail = true;
                nextView = views[currentViewIndex].closeView;
            }
            else if (Input.GetMouseButtonDown(0) && hit.collider.tag == "Restart")
            {
                BackToStart();
            }
        }

        // TODO remove, just for testing without JS
        //if (Input.GetKeyUp(KeyCode.Escape))
        //{
        //    CameraBack();
        //}

        // Just ignore everything if inside the detail view
        if (insideDetail)
            return;


        // ------- Scroll management -------

        // Add scroll to accumulator
        if (Input.mouseScrollDelta.y != 0)
        {

            if (Input.mouseScrollDelta.y > 0)
                scrollAccumulator += scrollValue;
            else
                scrollAccumulator -= scrollValue;

            lastScroll = Time.realtimeSinceStartupAsDouble;
        

            // Scroll accumulator reset and blocks
            if (scrollAccumulator >= 1.0F)
            {
                scrollAccumulator = 0;
                currentViewIndex ++;

                if (currentViewIndex >= views.Length)
                    currentViewIndex = views.Length - 1;

                nextView = views[currentViewIndex].standardView;
            }
            else if (scrollAccumulator < 0)
            {
                scrollAccumulator = 1F - scrollValue;
                currentViewIndex --;

                if (currentViewIndex < 0)
                {
                    currentViewIndex = 0;
                    scrollAccumulator = 0;
                }

                nextView = views[currentViewIndex].standardView;
            }
            
            if (currentViewIndex < views.Length - 1)
            {
                middlePositionGO.transform.position = Vector3.Lerp(views[currentViewIndex].standardView.position, views[currentViewIndex + 1].standardView.position, scrollAccumulator);
                middlePositionGO.transform.eulerAngles = new Vector3(
                    Mathf.LerpAngle(views[currentViewIndex].standardView.rotation.eulerAngles.x, views[currentViewIndex + 1].standardView.transform.rotation.eulerAngles.x, scrollAccumulator),
                    Mathf.LerpAngle(views[currentViewIndex].standardView.rotation.eulerAngles.y, views[currentViewIndex + 1].standardView.transform.rotation.eulerAngles.y, scrollAccumulator),
                    Mathf.LerpAngle(views[currentViewIndex].standardView.rotation.eulerAngles.z, views[currentViewIndex + 1].standardView.transform.rotation.eulerAngles.z, scrollAccumulator)
                );

                nextView = middlePositionGO.transform;
            }

        }

        // Scroll snap

        if (currentTime - lastScroll > snapSeconds && scrollAccumulator != 0)
        {
            currentViewIndex += (int) Math.Round(scrollAccumulator);
            scrollAccumulator = 0;

            nextView = views[currentViewIndex].standardView;

            Debug.Log("SNAP!");
        }

    }

    void LateUpdate()
    {

        // Check if the target position is different from the current one
        if (!(TansformEquals(transform, nextView)))
        {
            // Transition
            transform.position = Vector3.Lerp(transform.position, nextView.position, 3F * Time.deltaTime);
            transform.eulerAngles = new Vector3(
                Mathf.LerpAngle(transform.rotation.eulerAngles.x, nextView.transform.rotation.eulerAngles.x, 3F * Time.deltaTime),
                Mathf.LerpAngle(transform.rotation.eulerAngles.y, nextView.transform.rotation.eulerAngles.y, 3F * Time.deltaTime),
                Mathf.LerpAngle(transform.rotation.eulerAngles.z, nextView.transform.rotation.eulerAngles.z, 3F * Time.deltaTime)
            );

            // If the transition is near the end, snap it
            if (TansformEquals(transform, nextView))
            {
                transform.position = nextView.position;
                transform.eulerAngles = nextView.eulerAngles;
            }

        }
    }

    public void CameraBack()
    {

        // Trigger from JS:
        // - Intercept the unity instance from the init script
        // - Call [UNITY INSTANCE].SendMessage("Main camera", "CameraBack");

        Debug.Log("Triggered CameraBack function");

        insideDetail = false;
        nextView = views[currentViewIndex].standardView;
    }

    public void BackToStart()
    {
        Debug.Log("Triggered BackToStart function");

        insideDetail = false;
        nextView = views[0].standardView;
    }

    private Boolean TansformEquals(Transform t1, Transform t2)
    {
        return (t1.position - t2.position).sqrMagnitude  < 0.01f && Quaternion.Angle(t1.rotation, t2.rotation) < 0.01f;
    }
}
